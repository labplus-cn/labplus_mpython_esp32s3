/*
 * modxiaozhi.c - 小智AI语音会话 MicroPython 模块
 *
 * 向 MicroPython 层暴露小智AI语音会话功能。
 *
 * Python 用法示例:
 *
 *   import xiaozhi
 *
 *   def on_state(state):
 *       states = ["idle", "connecting", "listening", "speaking", "error"]
 *       print("State:", states[state])
 *
 *   def on_stt(text):
 *       print("You said:", text)
 *
 *   def on_tts(state, text):
 *       print("TTS:", state, text or "")
 *
 *   # 初始化
 *   xiaozhi.init("wss://api.tenclass.net/xiaozhi/v1/", "your-token")
 *
 *   # 注册回调（可选）
 *   xiaozhi.on_state(on_state)
 *   xiaozhi.on_stt(on_stt)
 *   xiaozhi.on_tts(on_tts)
 *
 *   # 启动语音会话
 *   xiaozhi.start()
 *
 *   # ... 等待 ...
 *
 *   # 中断说话（切回监听）
 *   xiaozhi.abort()
 *
 *   # 结束会话
 *   xiaozhi.stop()
 *
 *   # 查询状态
 *   print(xiaozhi.state())  # 0=idle 1=connecting 2=listening 3=speaking 4=error
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "py/runtime.h"
#include "py/objstr.h"
#include "py/mphal.h"
#include "py/gc.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#include "esp_log.h"
#include "xiaozhi_session.h"

#define TAG "modxiaozhi"

/* ====================================================
 * MicroPython 回调持久化（防止被 GC 回收）
 * ==================================================== */

static mp_obj_t s_on_state_cb    = mp_const_none;
static mp_obj_t s_on_stt_cb      = mp_const_none;
static mp_obj_t s_on_tts_cb      = mp_const_none;
static mp_obj_t s_on_llm_cb      = mp_const_none;
static mp_obj_t s_on_message_cb  = mp_const_none;

/* ====================================================
 * 内部 C 回调 → 调度到 MicroPython 调度器
 *
 * 注意: C 回调可能从 FreeRTOS 任务中被调用，
 *       不能直接调用 MicroPython 函数。
 *       使用 mp_sched_schedule() 将调用排队到 MicroPython 线程。
 * ==================================================== */

/* 用于传递 state 的包装结构 */
typedef struct { mp_obj_t cb; mp_obj_t arg; } mp_cb_pair_t;

/* ====================================================
 * C 回调实现:
 * 使用全局缓冲区 + 标志位的轮询方式
 * 从 FreeRTOS 任务安全地传递数据到 MicroPython 层。
 * 用户需在主循环中定期调用 xiaozhi.poll() 触发 Python 回调。
 * ==================================================== */

/* 简单的 C -> Python 调度：通过全局变量传递最新值 */
/* 这是在 FreeRTOS 任务和 MicroPython 线程间传递数据的简化方式 */

/* 最新消息缓冲区（用于跨任务传递） */
#define MSG_BUF_SIZE 512
static char s_last_stt[MSG_BUF_SIZE]     = {0};
static char s_last_tts_state[32]         = {0};
static char s_last_tts_text[MSG_BUF_SIZE]= {0};
static char s_last_llm_emotion[64]       = {0};
static char s_last_llm_text[MSG_BUF_SIZE]= {0};
static char s_last_message[MSG_BUF_SIZE] = {0};
static volatile int s_last_state = 0;

/* FreeRTOS 通知标志（用于标记有新数据待处理） */
static volatile uint32_t s_cb_flags = 0;
#define FLAG_STATE   (1 << 0)
#define FLAG_STT     (1 << 1)
#define FLAG_TTS     (1 << 2)
#define FLAG_LLM     (1 << 3)
#define FLAG_MESSAGE (1 << 4)

/* 用于保护 s_last_* 的互斥 */
static SemaphoreHandle_t s_msg_mutex = NULL;

/* C 层回调 - 只保存数据，不调用 Python */
static void c_on_state_impl(xiaozhi_state_t state)
{
    s_last_state = (int)state;
    s_cb_flags |= FLAG_STATE;
}

static void c_on_stt_impl(const char *text)
{
    if (!text) return;
    if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
    strncpy(s_last_stt, text, MSG_BUF_SIZE - 1);
    s_last_stt[MSG_BUF_SIZE - 1] = '\0';
    if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
    s_cb_flags |= FLAG_STT;
}

static void c_on_tts_impl(const char *state, const char *text)
{
    if (!state) return;
    if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
    strncpy(s_last_tts_state, state, sizeof(s_last_tts_state) - 1);
    if (text) strncpy(s_last_tts_text, text, MSG_BUF_SIZE - 1);
    else s_last_tts_text[0] = '\0';
    if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
    s_cb_flags |= FLAG_TTS;
}

static void c_on_llm_impl(const char *emotion, const char *text)
{
    if (!emotion) return;
    if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
    strncpy(s_last_llm_emotion, emotion, sizeof(s_last_llm_emotion) - 1);
    if (text) strncpy(s_last_llm_text, text, MSG_BUF_SIZE - 1);
    else s_last_llm_text[0] = '\0';
    if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
    s_cb_flags |= FLAG_LLM;
}

static void c_on_message_impl(const char *json)
{
    if (!json) return;
    if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
    strncpy(s_last_message, json, MSG_BUF_SIZE - 1);
    if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
    s_cb_flags |= FLAG_MESSAGE;
}

/* ====================================================
 * MicroPython 模块函数
 * ==================================================== */

/**
 * xiaozhi.init(url, token, device_id=None, client_id=None, volume=80)
 *
 * 初始化小智会话。
 *
 * Args:
 *   url       (str): WebSocket URL
 *   token     (str): Bearer 令牌
 *   device_id (str, optional): 设备 ID（默认使用 WiFi MAC）
 *   client_id (str, optional): 客户端 UUID（默认自动生成）
 *   volume    (int, optional): 扬声器音量 0-100（默认 80）
 */
static mp_obj_t mp_xiaozhi_init(size_t n_args, const mp_obj_t *pos_args,
                                 mp_map_t *kw_args)
{
    enum { ARG_url, ARG_token, ARG_device_id, ARG_client_id, ARG_volume };
    static const mp_arg_t allowed_args[] = {
        { MP_QSTR_url,       MP_ARG_REQUIRED | MP_ARG_OBJ, {.u_obj = mp_const_none} },
        { MP_QSTR_token,     MP_ARG_REQUIRED | MP_ARG_OBJ, {.u_obj = mp_const_none} },
        { MP_QSTR_device_id, MP_ARG_KW_ONLY  | MP_ARG_OBJ, {.u_obj = mp_const_none} },
        { MP_QSTR_client_id, MP_ARG_KW_ONLY  | MP_ARG_OBJ, {.u_obj = mp_const_none} },
        { MP_QSTR_volume,    MP_ARG_KW_ONLY  | MP_ARG_INT, {.u_int = 80} },
    };
    mp_arg_val_t args[MP_ARRAY_SIZE(allowed_args)];
    mp_arg_parse_all(n_args, pos_args, kw_args, MP_ARRAY_SIZE(allowed_args),
                     allowed_args, args);

    const char *url       = mp_obj_str_get_str(args[ARG_url].u_obj);
    const char *token     = mp_obj_str_get_str(args[ARG_token].u_obj);
    const char *device_id = (args[ARG_device_id].u_obj != mp_const_none)
                            ? mp_obj_str_get_str(args[ARG_device_id].u_obj) : NULL;
    const char *client_id = (args[ARG_client_id].u_obj != mp_const_none)
                            ? mp_obj_str_get_str(args[ARG_client_id].u_obj) : NULL;
    int volume = args[ARG_volume].u_int;

    /* 初始化互斥锁 */
    if (!s_msg_mutex) {
        s_msg_mutex = xSemaphoreCreateMutex();
    }

    xiaozhi_config_t config = {
        .url              = url,
        .token            = token,
        .device_id        = device_id,
        .client_id        = client_id,
        .frame_duration_ms= 60,
        .output_volume    = volume,
        .input_gain_db    = 35.0f,
    };

    esp_err_t err = xiaozhi_init(&config);
    if (err != ESP_OK) {
        mp_raise_msg_varg(&mp_type_RuntimeError,
                          MP_ERROR_TEXT("xiaozhi_init failed: %d"), err);
    }

    /* 注册 C 层回调 */
    xiaozhi_set_on_state(c_on_state_impl);
    xiaozhi_set_on_stt(c_on_stt_impl);
    xiaozhi_set_on_tts_state(c_on_tts_impl);
    xiaozhi_set_on_llm(c_on_llm_impl);
    xiaozhi_set_on_message(c_on_message_impl);

    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_KW(mp_xiaozhi_init_obj, 2, mp_xiaozhi_init);

/**
 * xiaozhi.deinit()
 *
 * 释放小智会话资源。
 */
static mp_obj_t mp_xiaozhi_deinit(void)
{
    esp_err_t err = xiaozhi_deinit();
    if (err != ESP_OK) {
        mp_raise_msg_varg(&mp_type_RuntimeError,
                          MP_ERROR_TEXT("xiaozhi_deinit failed: %d"), err);
    }
    /* 清空回调引用 */
    s_on_state_cb   = mp_const_none;
    s_on_stt_cb     = mp_const_none;
    s_on_tts_cb     = mp_const_none;
    s_on_llm_cb     = mp_const_none;
    s_on_message_cb = mp_const_none;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_deinit_obj, mp_xiaozhi_deinit);

/**
 * xiaozhi.start()
 *
 * 启动语音会话（连接服务器，开始收音）。
 * 此函数会阻塞直到握手完成或超时（最多 10 秒）。
 */
static mp_obj_t mp_xiaozhi_start(void)
{
    esp_err_t err = xiaozhi_start();
    if (err != ESP_OK) {
        mp_raise_msg_varg(&mp_type_RuntimeError,
                          MP_ERROR_TEXT("xiaozhi_start failed: %d"), err);
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_start_obj, mp_xiaozhi_start);

/**
 * xiaozhi.stop()
 *
 * 停止语音会话（断开连接）。
 */
static mp_obj_t mp_xiaozhi_stop(void)
{
    esp_err_t err = xiaozhi_stop();
    if (err != ESP_OK) {
        mp_raise_msg_varg(&mp_type_RuntimeError,
                          MP_ERROR_TEXT("xiaozhi_stop failed: %d"), err);
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_stop_obj, mp_xiaozhi_stop);

/**
 * xiaozhi.abort()
 *
 * 中断当前 TTS 播放，切回监听状态。
 */
static mp_obj_t mp_xiaozhi_abort(void)
{
    esp_err_t err = xiaozhi_abort();
    if (err != ESP_OK) {
        mp_raise_msg_varg(&mp_type_RuntimeError,
                          MP_ERROR_TEXT("xiaozhi_abort failed: %d"), err);
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_abort_obj, mp_xiaozhi_abort);

/**
 * xiaozhi.state() -> int
 *
 * 返回当前状态:
 *   0 = idle
 *   1 = connecting
 *   2 = listening
 *   3 = speaking
 *   4 = error
 */
static mp_obj_t mp_xiaozhi_get_state(void)
{
    return MP_OBJ_NEW_SMALL_INT((int)xiaozhi_get_state());
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_get_state_obj, mp_xiaozhi_get_state);

/* ---- 回调注册函数 ---- */

/**
 * xiaozhi.on_state(callback)
 *
 * 注册状态变化回调。
 * callback(state: int) 在状态改变时被调用。
 *
 * 注意: 回调不是实时的，需通过 xiaozhi.poll() 轮询触发。
 */
static mp_obj_t mp_xiaozhi_on_state(mp_obj_t cb)
{
    s_on_state_cb = cb;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(mp_xiaozhi_on_state_obj, mp_xiaozhi_on_state);

/**
 * xiaozhi.on_stt(callback)
 *
 * 注册语音识别结果回调。
 * callback(text: str) 在识别到语音时被调用。
 */
static mp_obj_t mp_xiaozhi_on_stt(mp_obj_t cb)
{
    s_on_stt_cb = cb;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(mp_xiaozhi_on_stt_obj, mp_xiaozhi_on_stt);

/**
 * xiaozhi.on_tts(callback)
 *
 * 注册 TTS 状态回调。
 * callback(state: str, text: str) 在 TTS 状态变化时被调用。
 * state: "start" / "stop" / "sentence_start"
 * text: 仅 sentence_start 时有值，其他为 None
 */
static mp_obj_t mp_xiaozhi_on_tts(mp_obj_t cb)
{
    s_on_tts_cb = cb;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(mp_xiaozhi_on_tts_obj, mp_xiaozhi_on_tts);

/**
 * xiaozhi.on_llm(callback)
 *
 * 注册 LLM 情感回调。
 * callback(emotion: str, text: str) 在收到 LLM 消息时被调用。
 */
static mp_obj_t mp_xiaozhi_on_llm(mp_obj_t cb)
{
    s_on_llm_cb = cb;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(mp_xiaozhi_on_llm_obj, mp_xiaozhi_on_llm);

/**
 * xiaozhi.on_message(callback)
 *
 * 注册原始 JSON 消息回调（用于高级处理）。
 * callback(json_text: str) 在收到任何 JSON 消息时被调用。
 */
static mp_obj_t mp_xiaozhi_on_message(mp_obj_t cb)
{
    s_on_message_cb = cb;
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(mp_xiaozhi_on_message_obj, mp_xiaozhi_on_message);

/**
 * xiaozhi.poll()
 *
 * 轮询待处理的回调事件并触发 Python 回调。
 * 需要在主循环中定期调用（建议 50ms 间隔）。
 *
 * 返回值: True 如果处理了任何事件，否则 False。
 *
 * 示例:
 *   import utime
 *   while True:
 *       xiaozhi.poll()
 *       utime.sleep_ms(50)
 */
static mp_obj_t mp_xiaozhi_poll(void)
{
    if (!s_cb_flags) {
        return mp_const_false;
    }

    bool handled = false;
    uint32_t flags = s_cb_flags;
    s_cb_flags = 0;  /* 清除标志（可能丢失并发更新，但简化了实现） */

    if ((flags & FLAG_STATE) && s_on_state_cb != mp_const_none) {
        mp_obj_t args[1] = { MP_OBJ_NEW_SMALL_INT(s_last_state) };
        mp_call_function_n_kw(s_on_state_cb, 1, 0, args);
        handled = true;
    }

    if ((flags & FLAG_STT) && s_on_stt_cb != mp_const_none) {
        if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
        mp_obj_t text = mp_obj_new_str(s_last_stt, strlen(s_last_stt));
        if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
        mp_obj_t args[1] = { text };
        mp_call_function_n_kw(s_on_stt_cb, 1, 0, args);
        handled = true;
    }

    if ((flags & FLAG_TTS) && s_on_tts_cb != mp_const_none) {
        if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
        mp_obj_t state_str = mp_obj_new_str(s_last_tts_state, strlen(s_last_tts_state));
        mp_obj_t text_str  = (s_last_tts_text[0])
                             ? mp_obj_new_str(s_last_tts_text, strlen(s_last_tts_text))
                             : mp_const_none;
        if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
        mp_obj_t args[2] = { state_str, text_str };
        mp_call_function_n_kw(s_on_tts_cb, 2, 0, args);
        handled = true;
    }

    if ((flags & FLAG_LLM) && s_on_llm_cb != mp_const_none) {
        if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
        mp_obj_t emotion = mp_obj_new_str(s_last_llm_emotion, strlen(s_last_llm_emotion));
        mp_obj_t text    = (s_last_llm_text[0])
                           ? mp_obj_new_str(s_last_llm_text, strlen(s_last_llm_text))
                           : mp_const_none;
        if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
        mp_obj_t args[2] = { emotion, text };
        mp_call_function_n_kw(s_on_llm_cb, 2, 0, args);
        handled = true;
    }

    if ((flags & FLAG_MESSAGE) && s_on_message_cb != mp_const_none) {
        if (s_msg_mutex) xSemaphoreTake(s_msg_mutex, portMAX_DELAY);
        mp_obj_t msg = mp_obj_new_str(s_last_message, strlen(s_last_message));
        if (s_msg_mutex) xSemaphoreGive(s_msg_mutex);
        mp_obj_t args[1] = { msg };
        mp_call_function_n_kw(s_on_message_cb, 1, 0, args);
        handled = true;
    }

    return handled ? mp_const_true : mp_const_false;
}
static MP_DEFINE_CONST_FUN_OBJ_0(mp_xiaozhi_poll_obj, mp_xiaozhi_poll);

/* ====================================================
 * 状态常量
 * ==================================================== */

/* 模块全局字典 */
static const mp_rom_map_elem_t xiaozhi_module_globals_table[] = {
    { MP_ROM_QSTR(MP_QSTR___name__),   MP_ROM_QSTR(MP_QSTR_xiaozhi) },

    /* 功能函数 */
    { MP_ROM_QSTR(MP_QSTR_init),       MP_ROM_PTR(&mp_xiaozhi_init_obj)      },
    { MP_ROM_QSTR(MP_QSTR_deinit),     MP_ROM_PTR(&mp_xiaozhi_deinit_obj)    },
    { MP_ROM_QSTR(MP_QSTR_start),      MP_ROM_PTR(&mp_xiaozhi_start_obj)     },
    { MP_ROM_QSTR(MP_QSTR_stop),       MP_ROM_PTR(&mp_xiaozhi_stop_obj)      },
    { MP_ROM_QSTR(MP_QSTR_abort),      MP_ROM_PTR(&mp_xiaozhi_abort_obj)     },
    { MP_ROM_QSTR(MP_QSTR_state),      MP_ROM_PTR(&mp_xiaozhi_get_state_obj) },
    { MP_ROM_QSTR(MP_QSTR_poll),       MP_ROM_PTR(&mp_xiaozhi_poll_obj)      },

    /* 回调注册 */
    { MP_ROM_QSTR(MP_QSTR_on_state),   MP_ROM_PTR(&mp_xiaozhi_on_state_obj)  },
    { MP_ROM_QSTR(MP_QSTR_on_stt),     MP_ROM_PTR(&mp_xiaozhi_on_stt_obj)    },
    { MP_ROM_QSTR(MP_QSTR_on_tts),     MP_ROM_PTR(&mp_xiaozhi_on_tts_obj)    },
    { MP_ROM_QSTR(MP_QSTR_on_llm),     MP_ROM_PTR(&mp_xiaozhi_on_llm_obj)    },
    { MP_ROM_QSTR(MP_QSTR_on_message), MP_ROM_PTR(&mp_xiaozhi_on_message_obj)},

    /* 状态常量 */
    { MP_ROM_QSTR(MP_QSTR_STATE_IDLE),       MP_ROM_INT(XIAOZHI_STATE_IDLE)       },
    { MP_ROM_QSTR(MP_QSTR_STATE_CONNECTING), MP_ROM_INT(XIAOZHI_STATE_CONNECTING) },
    { MP_ROM_QSTR(MP_QSTR_STATE_LISTENING),  MP_ROM_INT(XIAOZHI_STATE_LISTENING)  },
    { MP_ROM_QSTR(MP_QSTR_STATE_SPEAKING),   MP_ROM_INT(XIAOZHI_STATE_SPEAKING)   },
    { MP_ROM_QSTR(MP_QSTR_STATE_ERROR),      MP_ROM_INT(XIAOZHI_STATE_ERROR)      },
};

static MP_DEFINE_CONST_DICT(xiaozhi_module_globals, xiaozhi_module_globals_table);

const mp_obj_module_t xiaozhi_module = {
    .base    = { &mp_type_module },
    .globals = (mp_obj_dict_t *)&xiaozhi_module_globals,
};

MP_REGISTER_MODULE(MP_QSTR_xiaozhi, xiaozhi_module);
