/*
 * xiaozhi_session.c - 小智AI语音会话核心实现
 *
 * 实现了与小智AI服务器的 WebSocket 语音会话功能：
 *   - 连接/断开 WebSocket
 *   - Hello 握手协议
 *   - 麦克风 PCM → Opus 编码 → WebSocket 发送
 *   - WebSocket 接收 → Opus 解码 → 扬声器播放
 *   - JSON 消息处理 (STT/TTS/LLM 事件)
 *   - 状态机管理
 *
 * 音频约定:
 *   - 硬件采样率: 16000 Hz, 2 声道 (stereo), 16-bit PCM
 *     （需先调用 audio.init() 或手动初始化音频硬件）
 *   - Opus: 16000 Hz, mono, 60ms 帧
 *   - 收音: stereo → 取左声道 → mono → Opus 编码
 *   - 播放: Opus 解码 → mono → 复制为 stereo → 硬件
 *
 * 前置条件:
 *   调用 xiaozhi_init() 之前，必须先完成音频硬件初始化
 *   （在 MicroPython 层调用 audio.init() 或在 C 层调用
 *    esp_gmf_app_setup_codec_dev()）。
 */

#include "xiaozhi_session.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"

#include "esp_websocket_client.h"
#include "cJSON.h"

/* Opus 编码器 (直接使用 esp_opus_enc_process 等函数) */
#include "esp_audio_types.h"
#include "esp_audio_enc.h"
#include "esp_opus_enc.h"

/* Opus 解码器 */
#include "esp_audio_dec.h"
#include "esp_opus_dec.h"

/* GMF 音频硬件 */
#include "esp_gmf_app_setup_peripheral.h"
#include "esp_codec_dev.h"

/* ====================================================
 * 常量和宏定义
 * ==================================================== */

#define TAG "xiaozhi"

/* 音频硬件参数（与 audio.init() 中的参数保持一致） */
#define AUDIO_SAMPLE_RATE    16000
#define AUDIO_CHANNELS       2           /* 硬件为 stereo */
#define AUDIO_BITS           16
#define OPUS_FRAME_MS        60
#define OPUS_SAMPLE_RATE     16000
#define OPUS_CHANNELS        1           /* Opus mono */

/* 每帧样本数 (mono, 16kHz, 60ms) */
#define FRAME_SAMPLES        (OPUS_SAMPLE_RATE * OPUS_FRAME_MS / 1000)  /* 960 */
/* 硬件读取每帧字节数 (stereo 16-bit) */
#define HW_FRAME_BYTES       (FRAME_SAMPLES * AUDIO_CHANNELS * (AUDIO_BITS / 8))  /* 3840 */
/* Mono PCM 每帧字节数 */
#define MONO_FRAME_BYTES     (FRAME_SAMPLES * (AUDIO_BITS / 8))  /* 1920 */
/* Opus 输出缓冲区最大大小 */
#define OPUS_OUT_MAX_BYTES   512
/* Opus 解码输出最大大小 (60ms @ 16kHz mono 16-bit, 留余量) */
#define OPUS_DEC_OUT_BYTES   4096

/* Opus 语音编码比特率 (bps) - 语音模式下 32kbps 足够 */
#define OPUS_ENC_BITRATE     32000

/* 队列深度 */
#define SEND_QUEUE_SIZE      8
#define PLAY_QUEUE_SIZE      20

/* FreeRTOS 事件位 */
#define EVT_CONNECTED        (1 << 0)
#define EVT_DISCONNECTED     (1 << 1)
#define EVT_STOP_REQUESTED   (1 << 2)

/* WebSocket 接收缓冲区 */
#define WS_RECV_BUF_SIZE     4096

/* FreeRTOS 任务参数 */
#define CAPTURE_TASK_STACK   6144
#define CAPTURE_TASK_PRIO    7
#define PLAYBACK_TASK_STACK  8192
#define PLAYBACK_TASK_PRIO   7
#define WS_SEND_TASK_STACK   4096
#define WS_SEND_TASK_PRIO    6

/* ====================================================
 * 内部数据结构
 * ==================================================== */

/** Opus 数据包（用于队列传递） */
typedef struct {
    uint8_t data[OPUS_OUT_MAX_BYTES];
    int     len;
} opus_packet_t;

/** 全局会话状态 */
typedef struct {
    /* 配置 */
    char url[256];
    char token[256];
    char device_id[32];
    char client_id[64];
    int  frame_ms;

    /* 状态 */
    volatile xiaozhi_state_t state;
    char session_id[64];
    bool hello_received;

    /* WebSocket */
    esp_websocket_client_handle_t ws_client;

    /* Opus 编解码器句柄 */
    void *opus_encoder;
    void *opus_decoder;

    /* 音频硬件句柄 */
    esp_codec_dev_handle_t rec_dev;
    esp_codec_dev_handle_t play_dev;

    /* 队列 */
    QueueHandle_t send_queue;  /* capture → ws_send */
    QueueHandle_t play_queue;  /* ws_recv → playback */

    /* FreeRTOS 同步 */
    EventGroupHandle_t event_group;
    SemaphoreHandle_t  state_mutex;

    /* 任务句柄 */
    TaskHandle_t capture_task;
    TaskHandle_t playback_task;
    TaskHandle_t ws_send_task;

    /* 用户回调 */
    xiaozhi_on_state_t     on_state;
    xiaozhi_on_stt_t       on_stt;
    xiaozhi_on_tts_state_t on_tts_state;
    xiaozhi_on_llm_t       on_llm;
    xiaozhi_on_message_t   on_message;

} xiaozhi_ctx_t;

static xiaozhi_ctx_t *s_ctx = NULL;

/* ====================================================
 * 内部函数声明
 * ==================================================== */

static void set_state(xiaozhi_state_t new_state);
static esp_err_t ws_send_text(const char *text);
static esp_err_t send_hello(void);
static esp_err_t send_listen_start(void);
static esp_err_t send_listen_stop(void);
static esp_err_t send_abort_msg(void);
static void handle_json_message(const char *json_str);
static void ws_event_handler(void *handler_args, esp_event_base_t base,
                             int32_t event_id, void *event_data);
static void capture_task_fn(void *arg);
static void playback_task_fn(void *arg);
static void ws_send_task_fn(void *arg);
static void get_mac_str(char *buf, size_t len);

/* ====================================================
 * 状态管理
 * ==================================================== */

static void set_state(xiaozhi_state_t new_state)
{
    if (!s_ctx) return;
    xSemaphoreTake(s_ctx->state_mutex, portMAX_DELAY);
    xiaozhi_state_t old = s_ctx->state;
    s_ctx->state = new_state;
    xSemaphoreGive(s_ctx->state_mutex);

    if (old != new_state) {
        ESP_LOGI(TAG, "State: %d -> %d", (int)old, (int)new_state);
        if (s_ctx->on_state) {
            s_ctx->on_state(new_state);
        }
    }
}

/* ====================================================
 * JSON 消息发送
 * ==================================================== */

static esp_err_t ws_send_text(const char *text)
{
    if (!s_ctx->ws_client || !esp_websocket_client_is_connected(s_ctx->ws_client)) {
        return ESP_ERR_INVALID_STATE;
    }
    int ret = esp_websocket_client_send_text(s_ctx->ws_client, text,
                                             (int)strlen(text),
                                             pdMS_TO_TICKS(2000));
    if (ret < 0) {
        ESP_LOGE(TAG, "ws_send_text failed: %d", ret);
        return ESP_FAIL;
    }
    return ESP_OK;
}

static esp_err_t send_hello(void)
{
    cJSON *root  = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "type", "hello");
    cJSON_AddNumberToObject(root, "version", 1);
    cJSON_AddStringToObject(root, "transport", "websocket");

    cJSON *audio = cJSON_AddObjectToObject(root, "audio_params");
    cJSON_AddStringToObject(audio, "format", "opus");
    cJSON_AddNumberToObject(audio, "sample_rate", OPUS_SAMPLE_RATE);
    cJSON_AddNumberToObject(audio, "channels", OPUS_CHANNELS);
    cJSON_AddNumberToObject(audio, "frame_duration", s_ctx->frame_ms);

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!str) return ESP_ERR_NO_MEM;

    ESP_LOGD(TAG, "→ hello: %s", str);
    esp_err_t err = ws_send_text(str);
    free(str);
    return err;
}

static esp_err_t send_listen_start(void)
{
    cJSON *root = cJSON_CreateObject();
    if (s_ctx->session_id[0]) {
        cJSON_AddStringToObject(root, "session_id", s_ctx->session_id);
    }
    cJSON_AddStringToObject(root, "type", "listen");
    cJSON_AddStringToObject(root, "state", "start");
    cJSON_AddStringToObject(root, "mode", "auto");

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!str) return ESP_ERR_NO_MEM;

    ESP_LOGD(TAG, "→ listen start");
    esp_err_t err = ws_send_text(str);
    free(str);
    return err;
}

static esp_err_t send_listen_stop(void)
{
    cJSON *root = cJSON_CreateObject();
    if (s_ctx->session_id[0]) {
        cJSON_AddStringToObject(root, "session_id", s_ctx->session_id);
    }
    cJSON_AddStringToObject(root, "type", "listen");
    cJSON_AddStringToObject(root, "state", "stop");

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!str) return ESP_ERR_NO_MEM;

    esp_err_t err = ws_send_text(str);
    free(str);
    return err;
}

static esp_err_t send_abort_msg(void)
{
    cJSON *root = cJSON_CreateObject();
    if (s_ctx->session_id[0]) {
        cJSON_AddStringToObject(root, "session_id", s_ctx->session_id);
    }
    cJSON_AddStringToObject(root, "type", "abort");
    cJSON_AddStringToObject(root, "reason", "user");

    char *str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!str) return ESP_ERR_NO_MEM;

    esp_err_t err = ws_send_text(str);
    free(str);
    return err;
}

/* ====================================================
 * JSON 消息接收处理
 * ==================================================== */

static void handle_json_message(const char *json_str)
{
    /* 触发原始消息回调 */
    if (s_ctx->on_message) {
        s_ctx->on_message(json_str);
    }

    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
        ESP_LOGW(TAG, "JSON parse error: %.80s", json_str);
        return;
    }

    cJSON *type_j = cJSON_GetObjectItem(root, "type");
    if (!type_j || !cJSON_IsString(type_j)) {
        cJSON_Delete(root);
        return;
    }
    const char *type = type_j->valuestring;

    /* ---- hello ---- */
    if (strcmp(type, "hello") == 0) {
        cJSON *transport_j = cJSON_GetObjectItem(root, "transport");
        if (transport_j && cJSON_IsString(transport_j) &&
            strcmp(transport_j->valuestring, "websocket") == 0) {
            cJSON *sid_j = cJSON_GetObjectItem(root, "session_id");
            if (sid_j && cJSON_IsString(sid_j)) {
                strncpy(s_ctx->session_id, sid_j->valuestring,
                        sizeof(s_ctx->session_id) - 1);
            }
            s_ctx->hello_received = true;
            ESP_LOGI(TAG, "← hello ok, session=%s", s_ctx->session_id);
            xEventGroupSetBits(s_ctx->event_group, EVT_CONNECTED);
        }
    }
    /* ---- stt ---- */
    else if (strcmp(type, "stt") == 0) {
        cJSON *text_j = cJSON_GetObjectItem(root, "text");
        if (text_j && cJSON_IsString(text_j)) {
            ESP_LOGI(TAG, "← stt: %s", text_j->valuestring);
            if (s_ctx->on_stt) s_ctx->on_stt(text_j->valuestring);
        }
    }
    /* ---- tts ---- */
    else if (strcmp(type, "tts") == 0) {
        cJSON *state_j = cJSON_GetObjectItem(root, "state");
        cJSON *text_j  = cJSON_GetObjectItem(root, "text");
        const char *tts_state = (state_j && cJSON_IsString(state_j))
                                ? state_j->valuestring : "";
        const char *tts_text  = (text_j  && cJSON_IsString(text_j))
                                ? text_j->valuestring  : NULL;

        ESP_LOGI(TAG, "← tts state=%s", tts_state);

        if (strcmp(tts_state, "start") == 0) {
            /* 清空播放队列，切换为 SPEAKING */
            opus_packet_t tmp;
            while (xQueueReceive(s_ctx->play_queue, &tmp, 0) == pdTRUE) {}
            set_state(XIAOZHI_STATE_SPEAKING);
        } else if (strcmp(tts_state, "stop") == 0) {
            /* TTS 结束后等待播放队列清空，再切回 LISTENING */
            /* 由 playback_task 检测队列空并自动切换 */
        }

        if (s_ctx->on_tts_state) s_ctx->on_tts_state(tts_state, tts_text);
    }
    /* ---- llm ---- */
    else if (strcmp(type, "llm") == 0) {
        cJSON *emotion_j = cJSON_GetObjectItem(root, "emotion");
        cJSON *text_j    = cJSON_GetObjectItem(root, "text");
        const char *em   = (emotion_j && cJSON_IsString(emotion_j))
                           ? emotion_j->valuestring : "";
        const char *txt  = (text_j    && cJSON_IsString(text_j))
                           ? text_j->valuestring    : "";
        if (s_ctx->on_llm) s_ctx->on_llm(em, txt);
    }
    /* ---- system ---- */
    else if (strcmp(type, "system") == 0) {
        cJSON *cmd_j = cJSON_GetObjectItem(root, "command");
        if (cmd_j && cJSON_IsString(cmd_j) &&
            strcmp(cmd_j->valuestring, "reboot") == 0) {
            ESP_LOGW(TAG, "Server requested reboot");
            esp_restart();
        }
    }

    cJSON_Delete(root);
}

/* ====================================================
 * WebSocket 事件处理
 * ==================================================== */

static void ws_event_handler(void *handler_args, esp_event_base_t base,
                             int32_t event_id, void *event_data)
{
    if (!s_ctx) return;
    esp_websocket_event_data_t *data = (esp_websocket_event_data_t *)event_data;

    switch (event_id) {
    case WEBSOCKET_EVENT_CONNECTED:
        ESP_LOGI(TAG, "WS connected, sending hello");
        send_hello();
        break;

    case WEBSOCKET_EVENT_DISCONNECTED:
        ESP_LOGI(TAG, "WS disconnected");
        xEventGroupSetBits(s_ctx->event_group, EVT_DISCONNECTED);
        set_state(XIAOZHI_STATE_IDLE);
        break;

    case WEBSOCKET_EVENT_DATA:
        if (!data || !data->data_ptr || data->data_len <= 0) break;

        if (data->op_code == WS_TRANSPORT_OPCODES_BINARY) {
            /* 二进制：Opus 音频帧（仅 SPEAKING 状态下入队） */
            if (s_ctx->state == XIAOZHI_STATE_SPEAKING) {
                opus_packet_t pkt;
                int copy_len = (data->data_len < (int)sizeof(pkt.data))
                               ? data->data_len : (int)sizeof(pkt.data);
                memcpy(pkt.data, data->data_ptr, copy_len);
                pkt.len = copy_len;
                if (xQueueSend(s_ctx->play_queue, &pkt, 0) != pdTRUE) {
                    ESP_LOGW(TAG, "Play queue full, drop audio frame");
                }
            }
        } else if (data->op_code == WS_TRANSPORT_OPCODES_TEXT) {
            /* 文本：JSON 控制消息 */
            /* 注意：data->data_ptr 可能不以 null 结尾 */
            char *buf = malloc(data->data_len + 1);
            if (buf) {
                memcpy(buf, data->data_ptr, data->data_len);
                buf[data->data_len] = '\0';
                handle_json_message(buf);
                free(buf);
            }
        }
        break;

    case WEBSOCKET_EVENT_ERROR:
        ESP_LOGE(TAG, "WS error");
        xEventGroupSetBits(s_ctx->event_group, EVT_DISCONNECTED);
        set_state(XIAOZHI_STATE_ERROR);
        break;

    default:
        break;
    }
}

/* ====================================================
 * 音频捕获任务：麦克风 → Opus → 发送队列
 * ==================================================== */

static void capture_task_fn(void *arg)
{
    int16_t *hw_buf   = heap_caps_malloc(HW_FRAME_BYTES, MALLOC_CAP_DMA | MALLOC_CAP_8BIT);
    int16_t *mono_buf = malloc(MONO_FRAME_BYTES);
    uint8_t *opus_buf = malloc(OPUS_OUT_MAX_BYTES);

    if (!hw_buf || !mono_buf || !opus_buf) {
        ESP_LOGE(TAG, "capture_task OOM");
        goto cleanup;
    }

    ESP_LOGI(TAG, "Capture task started (frame=%dms, %d samples)", OPUS_FRAME_MS, FRAME_SAMPLES);

    while (true) {
        /* 检查停止请求 */
        if (xEventGroupGetBits(s_ctx->event_group) & EVT_STOP_REQUESTED) break;

        xiaozhi_state_t cur_state = s_ctx->state;

        if (cur_state == XIAOZHI_STATE_LISTENING) {
            /* 读取 stereo PCM */
            int bytes = esp_codec_dev_read(s_ctx->rec_dev, hw_buf, HW_FRAME_BYTES);
            if (bytes != HW_FRAME_BYTES) {
                ESP_LOGW(TAG, "codec read short: %d/%d", bytes, HW_FRAME_BYTES);
                vTaskDelay(pdMS_TO_TICKS(5));
                continue;
            }

            /* Stereo → Mono: 取左声道 */
            for (int i = 0; i < FRAME_SAMPLES; i++) {
                mono_buf[i] = hw_buf[i * 2];
            }

            /* Opus 编码 */
            esp_audio_enc_in_frame_t  in  = { .buffer = (uint8_t *)mono_buf,
                                               .len    = MONO_FRAME_BYTES };
            esp_audio_enc_out_frame_t out = { .buffer = opus_buf,
                                              .len    = OPUS_OUT_MAX_BYTES };
            esp_audio_err_t err = esp_opus_enc_process(s_ctx->opus_encoder, &in, &out);
            if (err != ESP_AUDIO_ERR_OK || out.encoded_bytes == 0) {
                /* DTX: silent frame, skip */
                continue;
            }

            /* 放入发送队列 */
            opus_packet_t pkt;
            int cplen = (out.encoded_bytes < (uint32_t)sizeof(pkt.data))
                        ? (int)out.encoded_bytes : (int)sizeof(pkt.data);
            memcpy(pkt.data, opus_buf, cplen);
            pkt.len = cplen;
            xQueueSend(s_ctx->send_queue, &pkt, 0);  /* 满则丢弃 */

        } else if (cur_state == XIAOZHI_STATE_SPEAKING) {
            /* 继续读取麦克风防止 I2S 溢出，但不发送 */
            esp_codec_dev_read(s_ctx->rec_dev, hw_buf, HW_FRAME_BYTES);
        } else {
            vTaskDelay(pdMS_TO_TICKS(20));
        }
    }

cleanup:
    ESP_LOGI(TAG, "Capture task done");
    if (hw_buf)   heap_caps_free(hw_buf);
    if (mono_buf) free(mono_buf);
    if (opus_buf) free(opus_buf);
    s_ctx->capture_task = NULL;
    vTaskDelete(NULL);
}

/* ====================================================
 * 音频播放任务：播放队列 → Opus 解码 → 扬声器
 * ==================================================== */

static void playback_task_fn(void *arg)
{
    uint8_t *pcm_mono   = malloc(OPUS_DEC_OUT_BYTES);
    int16_t *pcm_stereo = malloc(OPUS_DEC_OUT_BYTES * 2);  /* stereo, 有余量 */

    if (!pcm_mono || !pcm_stereo) {
        ESP_LOGE(TAG, "playback_task OOM");
        goto cleanup;
    }

    ESP_LOGI(TAG, "Playback task started");

    /* 用于检测 TTS 播放结束 */
    bool tts_stop_pending = false;
    TickType_t tts_stop_ts = 0;

    while (true) {
        if (xEventGroupGetBits(s_ctx->event_group) & EVT_STOP_REQUESTED) break;

        opus_packet_t pkt;
        BaseType_t got = xQueueReceive(s_ctx->play_queue, &pkt, pdMS_TO_TICKS(100));

        if (got != pdTRUE) {
            /* 队列超时 */
            if (s_ctx->state == XIAOZHI_STATE_SPEAKING) {
                /* 播放队列持续为空超过 200ms → TTS 可能已结束 */
                if (!tts_stop_pending) {
                    tts_stop_pending = true;
                    tts_stop_ts = xTaskGetTickCount();
                } else if ((xTaskGetTickCount() - tts_stop_ts) > pdMS_TO_TICKS(200)) {
                    ESP_LOGI(TAG, "Play queue drained, back to LISTENING");
                    set_state(XIAOZHI_STATE_LISTENING);
                    send_listen_start();
                    tts_stop_pending = false;
                }
            }
            continue;
        }
        tts_stop_pending = false;

        /* Opus 解码 */
        esp_audio_dec_in_raw_t raw = {
            .buffer       = pkt.data,
            .len          = (uint32_t)pkt.len,
            .consumed     = 0,
            .frame_recover= ESP_AUDIO_DEC_RECOVERY_NONE,
        };
        esp_audio_dec_out_frame_t frame = {
            .buffer      = pcm_mono,
            .len         = OPUS_DEC_OUT_BYTES,
            .needed_size = 0,
            .decoded_size= 0,
        };
        esp_audio_dec_info_t dec_info = {0};

        esp_audio_err_t err = esp_opus_dec_decode(s_ctx->opus_decoder,
                                                  &raw, &frame, &dec_info);
        if (err != ESP_AUDIO_ERR_OK) {
            ESP_LOGW(TAG, "Opus decode err: %d", err);
            continue;
        }
        if (frame.decoded_size == 0) continue;

        /* Mono → Stereo */
        int mono_samples  = (int)frame.decoded_size / sizeof(int16_t);
        int16_t *mono_ptr = (int16_t *)pcm_mono;
        for (int i = 0; i < mono_samples; i++) {
            pcm_stereo[i * 2]     = mono_ptr[i];
            pcm_stereo[i * 2 + 1] = mono_ptr[i];
        }

        /* 写入扬声器 */
        int stereo_bytes = mono_samples * 2 * (int)sizeof(int16_t);
        int written = esp_codec_dev_write(s_ctx->play_dev, pcm_stereo, stereo_bytes);
        if (written != stereo_bytes) {
            ESP_LOGW(TAG, "codec write short: %d/%d", written, stereo_bytes);
        }
    }

cleanup:
    ESP_LOGI(TAG, "Playback task done");
    free(pcm_mono);
    free(pcm_stereo);
    s_ctx->playback_task = NULL;
    vTaskDelete(NULL);
}

/* ====================================================
 * WebSocket 发送任务：发送队列 → WebSocket 二进制帧
 * ==================================================== */

static void ws_send_task_fn(void *arg)
{
    ESP_LOGI(TAG, "WS send task started");

    while (true) {
        if (xEventGroupGetBits(s_ctx->event_group) & EVT_STOP_REQUESTED) break;

        opus_packet_t pkt;
        if (xQueueReceive(s_ctx->send_queue, &pkt, pdMS_TO_TICKS(100)) != pdTRUE) {
            continue;
        }

        if (s_ctx->state == XIAOZHI_STATE_LISTENING &&
            s_ctx->ws_client &&
            esp_websocket_client_is_connected(s_ctx->ws_client)) {
            int ret = esp_websocket_client_send_bin(s_ctx->ws_client,
                                                    (const char *)pkt.data,
                                                    pkt.len,
                                                    pdMS_TO_TICKS(1000));
            if (ret < 0) {
                ESP_LOGW(TAG, "WS send_bin failed: %d", ret);
            }
        }
    }

    ESP_LOGI(TAG, "WS send task done");
    s_ctx->ws_send_task = NULL;
    vTaskDelete(NULL);
}

/* ====================================================
 * MAC 地址字符串
 * ==================================================== */

static void get_mac_str(char *buf, size_t len)
{
    uint8_t mac[6] = {0};
    esp_wifi_get_mac(WIFI_IF_STA, mac);
    snprintf(buf, len, "%02X:%02X:%02X:%02X:%02X:%02X",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/* ====================================================
 * 公开 API
 * ==================================================== */

esp_err_t xiaozhi_init(const xiaozhi_config_t *config)
{
    if (!config || !config->url || !config->token) {
        return ESP_ERR_INVALID_ARG;
    }
    if (s_ctx) {
        ESP_LOGW(TAG, "Already init, call deinit first");
        return ESP_ERR_INVALID_STATE;
    }

    s_ctx = calloc(1, sizeof(xiaozhi_ctx_t));
    if (!s_ctx) return ESP_ERR_NO_MEM;

    /* 复制配置 */
    strncpy(s_ctx->url,   config->url,   sizeof(s_ctx->url)   - 1);
    strncpy(s_ctx->token, config->token, sizeof(s_ctx->token) - 1);
    s_ctx->frame_ms = (config->frame_duration_ms > 0) ? config->frame_duration_ms : 60;

    /* 设备 ID */
    if (config->device_id && config->device_id[0]) {
        strncpy(s_ctx->device_id, config->device_id, sizeof(s_ctx->device_id) - 1);
    } else {
        get_mac_str(s_ctx->device_id, sizeof(s_ctx->device_id));
    }

    /* 客户端 UUID (基于 MAC) */
    if (config->client_id && config->client_id[0]) {
        strncpy(s_ctx->client_id, config->client_id, sizeof(s_ctx->client_id) - 1);
    } else {
        uint8_t mac[6] = {0};
        esp_wifi_get_mac(WIFI_IF_STA, mac);
        snprintf(s_ctx->client_id, sizeof(s_ctx->client_id),
                 "%02x%02x%02x%02x-%02x%02x-4%02x%02x-8%02x%02x-%02x%02x%02x%02x%02x%02x",
                 mac[0], mac[1], mac[2], mac[3],
                 mac[4], mac[5],
                 mac[0] ^ 0x5A, mac[1],
                 mac[2] | 0x80, mac[3],
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    }

    ESP_LOGI(TAG, "Init: device_id=%s", s_ctx->device_id);

    /* 获取音频硬件句柄（必须先调用 audio.init() 或 esp_gmf_app_setup_codec_dev()） */
    s_ctx->rec_dev  = (esp_codec_dev_handle_t)esp_gmf_app_get_record_handle();
    s_ctx->play_dev = (esp_codec_dev_handle_t)esp_gmf_app_get_playback_handle();

    if (!s_ctx->rec_dev || !s_ctx->play_dev) {
        ESP_LOGE(TAG, "Codec device not ready. Call audio.init() first.");
        free(s_ctx);
        s_ctx = NULL;
        return ESP_ERR_INVALID_STATE;
    }

    /* 设置音量和增益（可选） */
    if (config->output_volume > 0) {
        esp_codec_dev_set_out_vol(s_ctx->play_dev, config->output_volume);
    }
    if (config->input_gain_db > 0.0f) {
        esp_codec_dev_set_in_gain(s_ctx->play_dev, config->input_gain_db);
    }

    /* Opus 编码器 */
    {
        esp_opus_enc_config_t enc_cfg = {
            .sample_rate      = OPUS_SAMPLE_RATE,
            .channel          = ESP_AUDIO_MONO,
            .bits_per_sample  = ESP_AUDIO_BIT16,
            .bitrate          = OPUS_ENC_BITRATE,
            .frame_duration   = ESP_OPUS_ENC_FRAME_DURATION_60_MS,
            .application_mode = ESP_OPUS_ENC_APPLICATION_VOIP,
            .complexity       = 0,
            .enable_fec       = false,
            .enable_dtx       = false,
            .enable_vbr       = true,
        };
        esp_audio_err_t err = esp_opus_enc_open(&enc_cfg, sizeof(enc_cfg),
                                                &s_ctx->opus_encoder);
        if (err != ESP_AUDIO_ERR_OK || !s_ctx->opus_encoder) {
            ESP_LOGE(TAG, "Opus encoder init failed: %d", err);
            free(s_ctx); s_ctx = NULL;
            return ESP_FAIL;
        }
    }

    /* Opus 解码器 */
    {
        esp_opus_dec_cfg_t dec_cfg = {
            .sample_rate    = OPUS_SAMPLE_RATE,
            .channel        = ESP_AUDIO_MONO,
            .frame_duration = ESP_OPUS_DEC_FRAME_DURATION_60_MS,
            .self_delimited = false,
        };
        esp_audio_err_t err = esp_opus_dec_open(&dec_cfg, sizeof(dec_cfg),
                                                &s_ctx->opus_decoder);
        if (err != ESP_AUDIO_ERR_OK || !s_ctx->opus_decoder) {
            ESP_LOGE(TAG, "Opus decoder init failed: %d", err);
            esp_opus_enc_close(s_ctx->opus_encoder);
            free(s_ctx); s_ctx = NULL;
            return ESP_FAIL;
        }
    }

    /* FreeRTOS 资源 */
    s_ctx->send_queue  = xQueueCreate(SEND_QUEUE_SIZE,  sizeof(opus_packet_t));
    s_ctx->play_queue  = xQueueCreate(PLAY_QUEUE_SIZE,  sizeof(opus_packet_t));
    s_ctx->event_group = xEventGroupCreate();
    s_ctx->state_mutex = xSemaphoreCreateMutex();

    if (!s_ctx->send_queue || !s_ctx->play_queue ||
        !s_ctx->event_group || !s_ctx->state_mutex) {
        ESP_LOGE(TAG, "FreeRTOS object creation failed");
        esp_opus_enc_close(s_ctx->opus_encoder);
        esp_opus_dec_close(s_ctx->opus_decoder);
        if (s_ctx->send_queue)  vQueueDelete(s_ctx->send_queue);
        if (s_ctx->play_queue)  vQueueDelete(s_ctx->play_queue);
        if (s_ctx->event_group) vEventGroupDelete(s_ctx->event_group);
        if (s_ctx->state_mutex) vSemaphoreDelete(s_ctx->state_mutex);
        free(s_ctx); s_ctx = NULL;
        return ESP_ERR_NO_MEM;
    }

    s_ctx->state = XIAOZHI_STATE_IDLE;
    ESP_LOGI(TAG, "Init OK");
    return ESP_OK;
}

esp_err_t xiaozhi_deinit(void)
{
    if (!s_ctx) return ESP_ERR_INVALID_STATE;

    xiaozhi_stop();  /* 确保任务和连接已停止 */

    esp_opus_enc_close(s_ctx->opus_encoder);
    esp_opus_dec_close(s_ctx->opus_decoder);
    vQueueDelete(s_ctx->send_queue);
    vQueueDelete(s_ctx->play_queue);
    vEventGroupDelete(s_ctx->event_group);
    vSemaphoreDelete(s_ctx->state_mutex);

    free(s_ctx);
    s_ctx = NULL;
    ESP_LOGI(TAG, "Deinit OK");
    return ESP_OK;
}

esp_err_t xiaozhi_start(void)
{
    if (!s_ctx) return ESP_ERR_INVALID_STATE;
    if (s_ctx->state != XIAOZHI_STATE_IDLE &&
        s_ctx->state != XIAOZHI_STATE_ERROR) {
        ESP_LOGW(TAG, "Not idle, current state: %d", (int)s_ctx->state);
        return ESP_ERR_INVALID_STATE;
    }

    set_state(XIAOZHI_STATE_CONNECTING);
    xEventGroupClearBits(s_ctx->event_group, 0xFF);
    s_ctx->hello_received = false;
    memset(s_ctx->session_id, 0, sizeof(s_ctx->session_id));
    xQueueReset(s_ctx->send_queue);
    xQueueReset(s_ctx->play_queue);

    /* 构造 Authorization 头 */
    char auth_hdr[300];
    snprintf(auth_hdr, sizeof(auth_hdr), "Bearer %s", s_ctx->token);

    /* WebSocket 配置 */
    esp_websocket_client_config_t ws_cfg = {
        .uri                    = s_ctx->url,
        .buffer_size            = WS_RECV_BUF_SIZE,
        .task_stack             = 8192,
        .task_prio              = 5,
        .reconnect_timeout_ms   = 10000,
        .network_timeout_ms     = 10000,
        .disable_auto_reconnect = true,
    };

    s_ctx->ws_client = esp_websocket_client_init(&ws_cfg);
    if (!s_ctx->ws_client) {
        ESP_LOGE(TAG, "WS client init failed");
        set_state(XIAOZHI_STATE_ERROR);
        return ESP_FAIL;
    }

    /* 添加 HTTP 请求头 */
    esp_websocket_client_append_header(s_ctx->ws_client, "Authorization", auth_hdr);
    esp_websocket_client_append_header(s_ctx->ws_client, "Protocol-Version", "1");
    esp_websocket_client_append_header(s_ctx->ws_client, "Device-Id", s_ctx->device_id);
    esp_websocket_client_append_header(s_ctx->ws_client, "Client-Id",  s_ctx->client_id);

    /* 注册事件回调 */
    esp_websocket_register_events(s_ctx->ws_client, WEBSOCKET_EVENT_ANY,
                                  ws_event_handler, NULL);

    /* 启动连接 */
    esp_err_t err = esp_websocket_client_start(s_ctx->ws_client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "WS start failed: %s", esp_err_to_name(err));
        esp_websocket_client_destroy(s_ctx->ws_client);
        s_ctx->ws_client = NULL;
        set_state(XIAOZHI_STATE_ERROR);
        return err;
    }

    /* 等待服务器 hello 或超时 (10s) */
    EventBits_t bits = xEventGroupWaitBits(s_ctx->event_group,
                                           EVT_CONNECTED | EVT_DISCONNECTED,
                                           pdFALSE, pdFALSE,
                                           pdMS_TO_TICKS(10000));
    if (!(bits & EVT_CONNECTED) || (bits & EVT_DISCONNECTED)) {
        ESP_LOGE(TAG, "Hello timeout or disconnected");
        esp_websocket_client_stop(s_ctx->ws_client);
        esp_websocket_client_destroy(s_ctx->ws_client);
        s_ctx->ws_client = NULL;
        set_state(XIAOZHI_STATE_ERROR);
        return ESP_ERR_TIMEOUT;
    }

    /* 启动音频任务 */
    xTaskCreate(capture_task_fn,  "xz_cap",  CAPTURE_TASK_STACK,  NULL,
                CAPTURE_TASK_PRIO,  &s_ctx->capture_task);
    xTaskCreate(playback_task_fn, "xz_play", PLAYBACK_TASK_STACK, NULL,
                PLAYBACK_TASK_PRIO, &s_ctx->playback_task);
    xTaskCreate(ws_send_task_fn,  "xz_send", WS_SEND_TASK_STACK,  NULL,
                WS_SEND_TASK_PRIO,  &s_ctx->ws_send_task);

    /* 进入 LISTENING */
    set_state(XIAOZHI_STATE_LISTENING);
    send_listen_start();

    ESP_LOGI(TAG, "Session started");
    return ESP_OK;
}

esp_err_t xiaozhi_stop(void)
{
    if (!s_ctx) return ESP_ERR_INVALID_STATE;
    if (s_ctx->state == XIAOZHI_STATE_IDLE) return ESP_OK;

    ESP_LOGI(TAG, "Stopping");

    /* 发停止信号给任务 */
    xEventGroupSetBits(s_ctx->event_group, EVT_STOP_REQUESTED);

    /* 发送 goodbye */
    if (s_ctx->ws_client && esp_websocket_client_is_connected(s_ctx->ws_client)) {
        send_listen_stop();
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    /* 等待任务退出（最多 2s）*/
    int timeout_ms = 2000;
    while ((s_ctx->capture_task || s_ctx->playback_task || s_ctx->ws_send_task)
           && timeout_ms > 0) {
        vTaskDelay(pdMS_TO_TICKS(50));
        timeout_ms -= 50;
    }
    /* 超时强制删除 */
    if (s_ctx->capture_task)  { vTaskDelete(s_ctx->capture_task);  s_ctx->capture_task  = NULL; }
    if (s_ctx->playback_task) { vTaskDelete(s_ctx->playback_task); s_ctx->playback_task = NULL; }
    if (s_ctx->ws_send_task)  { vTaskDelete(s_ctx->ws_send_task);  s_ctx->ws_send_task  = NULL; }

    /* 停止 WebSocket */
    if (s_ctx->ws_client) {
        esp_websocket_client_stop(s_ctx->ws_client);
        esp_websocket_client_destroy(s_ctx->ws_client);
        s_ctx->ws_client = NULL;
    }

    xQueueReset(s_ctx->send_queue);
    xQueueReset(s_ctx->play_queue);
    xEventGroupClearBits(s_ctx->event_group, 0xFF);

    set_state(XIAOZHI_STATE_IDLE);
    ESP_LOGI(TAG, "Stopped");
    return ESP_OK;
}

esp_err_t xiaozhi_abort(void)
{
    if (!s_ctx) return ESP_ERR_INVALID_STATE;
    if (s_ctx->state != XIAOZHI_STATE_SPEAKING &&
        s_ctx->state != XIAOZHI_STATE_LISTENING) {
        return ESP_ERR_INVALID_STATE;
    }
    /* 清空播放队列 */
    opus_packet_t pkt;
    while (xQueueReceive(s_ctx->play_queue, &pkt, 0) == pdTRUE) {}

    send_abort_msg();
    set_state(XIAOZHI_STATE_LISTENING);
    send_listen_start();
    return ESP_OK;
}

xiaozhi_state_t xiaozhi_get_state(void)
{
    return s_ctx ? s_ctx->state : XIAOZHI_STATE_IDLE;
}

void xiaozhi_set_on_state(xiaozhi_on_state_t cb)
{
    if (s_ctx) s_ctx->on_state = cb;
}
void xiaozhi_set_on_stt(xiaozhi_on_stt_t cb)
{
    if (s_ctx) s_ctx->on_stt = cb;
}
void xiaozhi_set_on_tts_state(xiaozhi_on_tts_state_t cb)
{
    if (s_ctx) s_ctx->on_tts_state = cb;
}
void xiaozhi_set_on_llm(xiaozhi_on_llm_t cb)
{
    if (s_ctx) s_ctx->on_llm = cb;
}
void xiaozhi_set_on_message(xiaozhi_on_message_t cb)
{
    if (s_ctx) s_ctx->on_message = cb;
}
